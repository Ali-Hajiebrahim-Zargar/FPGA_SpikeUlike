﻿Mercury XU5 Qt6 GUI - Windows x64 Portable Package

Run Mercury_XU5_GUI.exe from this extracted folder.

Keep the DLL files and the platforms subdirectory
alongside the executable.

Built with Qt 6.12.0 and MinGW GCC 13.1.0.

The included Qt libraries are dynamically linked.
Their redistribution is subject to the applicable
Qt license terms. Review Qt licensing obligations:
https://www.qt.io/licensing/

Source code:
https://github.com/Ali-Hajiebrahim-Zargar/FPGA_SpikeUlike

Hardware testing is not included in this build check.
